## 2.3.2 re-release (August 16, 2020)

Patch to update jQuery in Bower

## v1.1.0
- **Added support for IE7 and IE8**
- Added examples directory with first example usage of Rockskeleton for a simple website
- Syntax fixes for gradients and color-stops
- Miscellaneous updates to docs
- Bug fixes

## v1.0.0
- **Initial release**